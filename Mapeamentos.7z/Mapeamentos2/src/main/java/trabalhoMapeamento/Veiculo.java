package trabalhoMapeamento;

public class Veiculo {

}
